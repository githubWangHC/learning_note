create dataFrame from CSV files, 
use DateFarme: lsit, dictionary, np ndarray
index rows columns
df to array   df to dict
df select:  quera  isin   loc
pd merge, group, sort,duplicates,concatenate

print('Number of reviews: {}'.format(len(df)))
'%s %s' % ('one', 'two')；'{} {}'.format('one', 'two')，后者更简单

if sys.version_info[0] > 2:
    #sys.version_info(major=3, minor=7, micro=1, releaselevel='final', serial=0)
    is_py3 = True
else:
    reload(sys)
    sys.setdefaultencoding("utf-8")
    is_py3 = False
file in os.listdir("../input/"):
filelist = [os.path.join("/dir/", fi) for fi in fis if fi[-3:]  == "bin"]
raw_text = open('../input/Winston_Churchil.txt').read()
raw_text = raw_text.lower()

def open_file(filename, mode='r'):
    """
    常用文件操作，可在python2和python3间切换.
    mode: 'r' or 'w' for read or write
    """
    datasets = {
        'unlabeled_train': 'unlabeledTrainData.tsv',
        'labeled_train': 'labeledTrainData.tsv',
        'test': 'testData.tsv'
    }
    if filename not in datasets:
        raise ValueError(filename)
        
    if is_py3:  #ISO-8859-1
        return open(filename, mode, encoding='utf-8', errors='ignore')
    else:
        return open(filename, mode)

if not isinstance(sentence, text_type):
    try:
        sentence = sentence.decode('utf-8')
    except UnicodeDecodeError:
        sentence = sentence.decode('gbk', 'ignore')

def native_content(content):
    if not is_py3:
        return content.decode('utf-8')
    else:
        return content

categories = ['体育', '财经', '房产', '家居', '教育', '科技', '时尚', '时政', '游戏', '娱乐']
categories = [native_content(x) for x in categories]

def read_file(filename):
    """读取文件数据"""
    contents, labels = [], []
    with open_file(filename) as f:
        for line in f:
            try:
                label, content = line.strip().split('\t')#按照tab键分割得到label与content
                if content:
                    contents.append(list(native_content(content)))#转换成列表
                    labels.append(native_content(label))
            except:
                pass
    return contents, labels

texts = [[word for word in line.strip().lower().split() if word not in stop_list] for line in f]

csv_file = open("log_origine.csv", 'a', encoding='UTF-8', newline='')
writer = csv.writer(csv_file)
writer.writerow(["data","time","app name", "contents"])
writer.writerow([data_M_D, data_H_m_S, app, log])

data = np.loadtxt(path, dtype=float, delimiter=',', converters={4: iris_type})
print data  //这样只能读取比较规整的数据
# 将数据的0到3列组成x，第4列得到y
x, y = np.split(data, (4,), axis=1)

===========
===cread df===
===========
df_ = pd.DataFrame(index=index, columns=columns)
df_ = df_.fillna(0) # with 0s rather than NaNs

====from csv file====
df = pd.read_csv('data.csv', dtype={'age':int}, sep='\t', escapechar='\\')
df = pd.read_table("val.txt", names = ["label", "title"], encoding = "utf-8")
del df
df.to_csv(os.path.join('..', 'data', 'Bag_of_Words_model.csv'), index=False)
return <class 'pandas.core.frame.DataFrame'>，
data.csv也可以换成网站链接
通过指定某一列的数据类型可以减少内存的消耗；
windows 中的路径是以\分割的，当\后接abfnrtv时会转义.https://docs.python.org/2.0/ref/strings.html

print(df.describe())
如果是df中某一列是数值的话可以对该列打印出计数，mean，等统计参数，如果是字符则不做统计。
print(df.head(10))
df.shape     shape不是函数，不用括号

===df & numpy ndarray & list==
===df 2 lists
data = [['Alex',10],['Bob',12],['Clarke',13]]
df = pd.DataFrame(data,columns=['Name','Age'],dtype=float)
===np to df
dates = pd.date_range('1/1/2000', periods=8)
df = pd.DataFrame(np.random.randn(8, 4), index=dates, columns=['A', 'B', 'C', 'D'])#以dates为索引生成一个8行×4列的矩阵，表头是ABCD
np.zeros[1, 3]创建一个0矩阵
===df to np
values = df.values
type(values)    <class 'numpy.ndarray'>
X = values[:,0:8]
y = values[:,8]
np_ndarry = pd.as_matrix()
==dic 2 df
#ABC是列名，字符串用空格分隔
data = {'A': 'foo bar foo bar foo bar foo foo'.split(), 'C': np.arange(8), 'D': np.arange(8) * 2}
df = pd.DataFrame(data)
print df ['A']                  #选择A列输出
===df 2 dict
df = pd.DataFrame({'col1': [1, 2], 'col2': [0.5, 0.75]}, index=['a', 'b'])
dict = df.to_dict()
{'col1': {'a': 1, 'b': 2}, 'col2': {'a': 0.5, 'b': 0.75}}
<class 'dict'>

===index column or row in df===
train = pd.DataFrame([[0,1,2,3]],columns=['A','D','E','G'])
train
   A  D  E  G
0  0  1  2  3
test = pd.DataFrame([[0,1,2,3,4,5,6],[0,1,2,3,4,5,6]],columns=['A','B','C','D','E','F','G'])
test
   A  B  C  D  E  F  G
0  0  1  2  3  4  5  6
0  0  1  2  3  4  5  6
test_df = test[train.columns]
test_df
   A  D  E  G
0  0  3  4  6
0  0  3  4  6

test_df = test_df.values.astype(str)
[['0' '3' '4' '6']
 ['0' '3' '4' '6']]
X_train = np.array([' '.join(x) for x in test_df])
['0 3 4 6' '0 3 4 6']
====index column===
a = df[['A', 'B']]
df['E'] = df['C'] + df['D']  #增加一列

X = df.iloc[ :, :-1].value#从第0列到倒数最后一列是X, integer-location
Y = df.iloc[ :, 3].value  #第3列是Y
#DataFrame数据结构只能通过这种方式来索引，数组才能直接通过X[:, 3]索引
values = df.values
type(values)    <class 'numpy.ndarray'>
X = values[:,0:8]
y = values[:,8]
=== index row ===
print df.loc['2000-01-02']#选择2000-01-02这一行
print df.iloc[2]#选择第2行输出（从第0行开始）,方括号
print df.iloc[2, :]  等价于上面。

===data select====
df = df.query("x > 1.0 &  x < 1.25 & y > 2.5 & y < 2.75")#筛选出‘x’列与‘y’列符合预期的数据
df = df[df.A > 3]#筛选出df中A列元素大于3的部分。
df1['A'].isin(df2['B']).value_counts()#统计df1中A列与df2中B列数值相等的个数
df1['A'].isin(df2['B'])  等价于  df1.A.isin(df2.B) #用[]是为了多列比较，，单列时可以点出来，需要注意的是isin是一个函数，需要用 ()。

df.loc[(df['A'] == value1) & df['B'].isin(value2)]
#筛选出 A列中值为value1且B列中值为value2的数值。
df.loc[df['A'] != value1]
df.loc[~df['B'].isin(value2)]

=== NAN ===

df.replace(to_replace = "?", value = np.nan)  标记
===统计缺失值
data_for_age = data[['Age', 'Survived', 'Fare', 'Parch', 'SibSp', 'Pclass']]
age_exist = data_for_age.loc[(data.Age.notnull())]   # 年龄不缺失的数据
age_null = data_for_age.loc[(data.Age.isnull())]

df.isnull().sum()    或者使用     df.describe()

==numpy.ndarray==
list = [1, 2, 3, 4, np.nan]                       <class 'list'>
array = np.array(list)        <class 'numpy.ndarray'>
np.isnan(array)
array([False, False, False, False,  True])
np.isnan(array).sum()                          return 1

============
===填充缺失值===
==numpy.ndarray==
from sklearn.preprocessing import Imputer
inputer = Imputer(missing_values = "NaN", strategy = "mean", axis = 0)
用列的mean，median 等填充缺失值，也可以写成“nan"
X[:, 0:3] = imputer.fit_transform(X[:, 1:3])
return 'numpy.ndarray'

==pandas.DataFrame==
DataFrame 要先转换再使用Imputer：
v1 = df.values
v2 = imputer.fit_transform(v1)
或者使用fillna()
df['age'].fillna(df['age'].mean(), inplace=True)
mean()是用一个固定均值去填充，也可以用一些策略bfill，ffill等待。

=====将缺失值删除===
# mark zero values as missing or NaN
df[[1,2]] = df[[1,2]].replace(0, numpy.NaN)
# drop rows with missing values
df.dropna(inplace=True, how='any')

===增加一列1===
x = np.array([np.concatenate((v,[1])) for v in boston.data])
一个数据应该就是一行，或者用下面这种方式
pd.insert(0, 'one', 1)，在第0列插入一列1
y = np.concatenate((np.ones(len(pos)), np.zeros(len(neg))))
np.save('data/y_train.npy',y_train)
train_vecs=np.load('data/train_vecs.npy')

lagou_df2['Python'] = pd.Series()
for i, j in enumerate(lagou_df2['position_detail']):
    if 'Python' in j:
        lagou_df2['Python'][i] = 1
    else:
        lagou_df2['Python'][i] = 0

embarked_data = embarked_data.rename(columns=lambda x: 'Embarked_' + str(x))
data = pd.concat([data, embarked_data], axis=1)
==============
===merge ======
=============
df = df.append(df2)#将df2加到df后。
mt = pd.merge(df1, df2, on=['A', 'B'])#将 df1与df2合并合并的依据是df1中的A列与B列中的字段相同,合并之后mt中只有A列与B列中相同的字段,
mt = pd.merge(df1, df2, left_on='A', right_on = 'B'])#与上面等价.

df = pd.merge(df1, df2[['d', 'e', 'f']], on='d')
#df前几列是df1,后面还有df2的三列d, e, f; 合并的依据是df1的d列数值与df2的d列元素相同.
#上面的这种合并方式只是将df1与df2中d列中公共的行筛选出来，是默认的筛选方式，how = 'inner'；同样how = 'left'保留了df1中的所有元素，df2的d列中不包含df1中d列的元素填上NaN；how = 'right'与上面相反；how = 'outer'则是同时保留df1与df2中的数据。
#如果想追踪某一行数据到底是源自那个文件则可以在merge中添加一个参数indicator=True。这样在合并之后的表格中就会增加一列‘merge’merge中会有both、right、left来区分三种数据来源。
https://www.shanelynn.ie/merge-join-dataframes-python-pandas-index-1/


data = pd.concat((pd.concat((pd.concat((data1, data2)), data3)), data4)).reset_index(drop=True)
==========
===group===
==========
数据之前默认按照序列从0开始依次排列，现在按照A列进行分组，相当于自变量是A，对于A列中的元素a，其他列至少有一个与其相对，单更多的是有很多数值与其相对应，但a只有一行，即使有很多与其相对应也只能填上一个，所以就需要事先制定好规则：多个进行计数还是平均等。如果是计数的话每一行都是相同的，平均则不一样。
result.groupby("manufacturer").agg({
        "outgoing_mins_per_month": "mean",
        "use_id": "count"
    })
#df中有三列，现在要以手机制造商进行分组，分组后可以看到iphone厂家一共有多少用户在用，以及这些用户的平均户外使用时间。
#代码执行完之后result中的索引就是 manufacturer，这时我们不能对其进行索引。如果想让跟组后 A仍然单独成一列的话就需要这样：
result.groupby("A", as_index = False).agg({"B": "mean", "C": "count"})

=== sort ===
df.sort_values('A', inplace = True)
将df中的数值 进行排序，排序的依据是A列元素，

====drop====
df.drop_duplicates(subset ="A", keep = first, inplace = True) 
#对df中的A列进行去重，keep = first表示第一个元素从被认为是独特的，遇到第二次才被认为是重复；相对应last表示如果有重复则最后一个元素才被认为是重复；Fase则表示所有的内容被认为是重复的，也就是重复的元素一个不留。inplace = True表示所有的重复都会被去掉。

cross = pd.crosstab(mt['user_id'], mt['aisle'])#将表的索引变为user_id
#交叉表格http://pbpython.com/pandas-crosstab.html

del df['C']                           删除C列
df = df.drop(['C'], axis=1)
df 中行为x，为0；列为y为1

========
for f in range(0, 3):
    fare[f] = data[data.Pclass == f + 1]['Fare'].dropna().median()
for f in range(0, 3):  # loop 0 to 2
    data.loc[(data.Fare.isnull()) & (data.Pclass == f + 1), 'Fare'] = fare[f]
    
    
内容提要:
LabelEncoder 处理函数, 处理流程;     OneHotEncoder函数初始化, 转换流程;
NaN                 缺失值处理
MinMaxScaler  数据归一化
StandardScaler 标准化函数
PCA                   主成份分析
 train_test_split  分组函数引入及使用;  

===LabelEncoder===
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
le = LabelEncoder()#J用不同数字代表字符串
X[:, 0] = encoder.fit_transform(X[:, 0])
#fit_transform = fit + transform；fit只计算，计算结果（比如均值）保存在encoder中，下次调用encoder.transform()时再使用。
lbl = LabelEncoder()
lbl.fit(list(lagou_df['city'].values))#df要先转换为np
lagou_df['city'] = lbl.transform(list(lagou_df['city'].values))

categories = ['体育', '财经', '房产', '家居', '教育', '科技', '时尚', '时政', '游戏', '娱乐']
cat_to_id = dict(zip(categories, range(len(categories))))#建立一个字典
{'体育': 0, '财经': 1, '房产': 2, '家居': 3, '教育': 4, '科技': 5, '时尚': 6, '时政': 7, '游戏': 8, '娱乐': 9}
data_id.append([cat_to_id[x] for x in contents[i] if x in cat_to_id])

chars = sorted(list(set(raw_text)))
char_to_int = dict((c, i) for i, c in enumerate(chars))
int_to_char = dict((i, c) for i, c in enumerate(chars))

===OneHotEncoder===
encoder = OneHotEncoder(categorical_feature = [0]) #第0列是要转换的feature列.
X = encoder.fit_transform(X).toarray()
display or arrange (things) in a particular way
转换之后第0列扩展为n列(n为0列的特征数)，n列共同表示原来一列的特征。
data['Sex'] = data['Sex'].map({'female': 0, 'male': 1}).astype(int)
类别不转换成onehot也可以，根据实际情况定。
# 再由硬编码转为one-hot编码
df_city = OneHotEncoder().fit_transform(lagou_df['city'].values.reshape((-1,1))).toarray()

# pandas one-hot方法
pd.get_dummies(lagou_df['city']).head()

上海	其他	北京	南京	广州	成都	杭州	武汉	深圳
0	0	0	0	0	0	1	0	0	0
1	0	0	1	0	0	0	0	0	0

====归一化处理======
#根据算法的要求，如果特征是同等重要的则进行缩放；使得一个特征不会对结果造成大的影响。
#但是对异常值处理不够，鲁棒性差。
from sklearn.preprocessing import MinMaxScaler
mm = MinMaxScaler(feature_range=(2, 3))
list = mm.fit_transform(list)#将list转换为2到3之间
df  = mm.fit_transform(df) 将df转换到2到3之间

===StandardScaler===
标准差的转换算法：x - mean/方差，将一个特征转换为均值为0，方差为1的特征。标准化缩放，克服可异常值，在数据比较大的时候有用。平均值受异常值的影响不大。方差表示数据的稳定性
from sklearn.preprocessing import StandardScaler
sc_X = StandardScaler()
X_train = sc_X.fit_transform(X_train)#分别初始化
X_test = sc_X.transform(X_test)#这个地方只能用transform，要用同一个标准

数据降维 即 减少特征数量
1. 删除低方差的特征
from sklearn.feature_selection import VarianceThreshold
var = VarianceThreshold(threshold=0.1)
data = var.fit_transform([[0, 2, 0, 3], [0, 1, 4, 3], [0, 1, 1, 3]])
数组中的每一列都是一个特征，计算每一列的方差，低于0.1的就删除

2. Principal component analysis (PCA)主成份分析，达到100个特征的时候 使用
from sklearn.decomposition import PCA
pca = PCA(n_components=0.9)
保存90%的信息，一般设置为90%～95%，为整数时减少到的特征数量 n_components也可以等于min(n_samples, n_features)
data = pca.fit_transform([[2,8,4,5],[6,3,0,8],[5,4,9,1]])
转换的结果不能用head和shape

train/test切分
from sklearn.model_selection improt train_test_split
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size = 0.25, random_state = 0)
X是特征值，Y是目标值。random_state可以是任意整数，由于不同的次序会对预测结果有影响，所以要检验算法时可以将这个参数设定为一个定值，这样可以保证打乱的结果是一样的。比例从经验看0.25比较好。
返回值先是特征值，后是目标值
#转换完之后成为numpy.ndarray类型，不再有shape，head等函数可供查看内容

extraction feature from dict, 中文
analysis: Count,Tfidf _Vectorizer
time: to_datetime, DataTimeIndex
============
==字典特征提取==
============
from sklearn.feature_extraction import DictVectorizer
dict = DictVectorizer(sparse=False)
sparse 格式用下标表示为1的位置，节约内存方便处理；若为false则转换为 ndarray 数组
data = dict.fit_transform([{'city': '北京','temperature': 100}, {}, {}])
print(dict.get_feature_names())
打印要转换的feature name不计重复，可作为data的表头
print(data)
print(dict.inverse_transform(data))#将data中要转换的内容替换成数字

这个函数只能接受字典，pd.to_dict()，参考数据加载中将pandas.DataFrame 转换为dictionary

verbose
from sklearn.datasets.samples_generator import make_regression
X, y, coef = make_regression(n_samples=n_train + n_test, n_features=n_features, noise=noise, coef=True)


colored = ['orange', 'green', 'blue', 'purple']
colr = [colored[i] for i in predict]
plt.scatter(x[:, 1], x[:, 20], color=colr)

from matplotlib.colors import ListedColormap
X_set, Y_set = X_train, y_train
X1, X2 = np.meshgrid(np.arange(start = X_set[:, 0].min() - 1, stop = X_set[:, 0].max() + 1, step = 0.01),np.arange(start = Y_set[:, 1].min() - 1, stop = Y_set[:, 1].max() + 1, step = 0.01))
#np.arange生成一个数组，由开始、结束、步长；
#.reshape，按照某个矩阵来重塑矩阵。
plt.contourf(X1, X2, classifier.predict(np.array([X1.ravel(), X2.ravel()]).T).reshape(X1.shape),alpha = 0.75, cmap = ListedColormap(('red', 'green')))
plt.xlim(X1.min(), X1.max())
plt.ylim(X2.min(), X2.max())
for i, j in enumerate(np.unique(y_set)):
    plt.scatter(X_set[y_set == j, 0], X_set[y_set == j, 1],c = ListedColormap(('red', 'green'))(i), label = j)
plt.title('SVM (Training set)')
plt.xlabel('Age')
plt.ylabel('Estimated Salary')
plt.legend()
plt.show()

=========
==中文分词==
=========
# 去除空格
char = '    louwill is a machine learning engineer.    '
char.strip()

# 字符串分割
char2 = 'louwill,is,a,machine,learning,engineer.'
char2.split(',')

# 拼接：列表转字符串
char2_2 = char2.split(',')
','.join(char2_2)

for i, j in enumerate(data['salary']):
    j = j.replace('k', '').replace('K', '').replace('以上', '-0')
    j1 = int(j.split('-')[0])
    j2 = int(j.split('-')[1])
    j3 = 1/2 * (j1+j2)
    data['salary'][i] = j3*1000

data['work_year'].value_counts()

import jieba
con1 = jieba.cut("今天很残酷，。。。")#<class 'generator'
lsit_str = list(con1)    #转换为list
str = ' '.join(lsit_str)   #将list中的元素以空格分隔转成字符串。
===词频统计分析===
from sklearn.feature_extraction.text import CountVectorizer
vector = CountVectorizer()
res = vector.fit_transform(["life is ,is like py"])
==return class 'scipy.sparse.csr.csr_matrix'==
print(vector.get_feature_names())#将文章中所有不同字符串成一行N列
print(res.toarray())#成为一个矩阵2×N
返回值是一个 class 'numpy.ndarray'
print(res)#节约内存，将上述矩阵中有数值的地方列出，并显示出频率

====处理时间的数据====
time_value = pd.to_datetime(df['time'], unit='s')
把日期格式转换成 字典格式
time_value = pd.DatetimeIndex(time_value)
构造一些特征
df['day'] = time_value.day
df['hour'] = time_value.hour
df['weekday'] = time_value.weekday

#但是这些方法没有下面方法好
data_slect.loc[:, 'day'] = dataTime_dic.day
data_slect.loc[:, 'weekday'] = dataTime_dic.weekday
data_slect.loc[:, 'hour'] = dataTime_dic.hour

===============
一份完整的数据分析/机器学习分析报告通常包括：
小四，1.5行间距
背景介绍

业务背景介绍，
需求分析
目标
...
数据来源和数据说明

数据采集描述，网站，
数据基本状况说明，那些变量，多少特征，数据量多少，均衡
预处理简要描述
...
探索性数据分析与数据可视化

描述性数据分析
目标变量重点探索
各种绘图与数据可视化参考
特征工程相关
...
机器学习模型部分

模型尝试和实验过程描述，融合了哪些模型
模型诊断与调优
模型结果展示
...
结论与建议

根据模型结果给出结论
模型不足之处
后续的研究工作
...

模型的保存
from sklearn.externals import joblib
clf=SVC(kernel='rbf',verbose=True)
clf.fit(train_vecs,y_train)

model_name = '{}features_{}minwords_{}context.model'.format(num_features, min_word_count, context)
joblib.dump(clf, os.path.join('..', 'models', model_name))
clf=joblib.load(os.path.join('..', 'models', model_name))

'''函数修饰符 https://blog.csdn.net/tanyjin/article/details/74363797
def test(f):
    print("before ...")
    f()
    print("after ...")
 
@test
def func():
    print("func was called")
before ...
func was called
after ...
'''

def print_call_counts(f):
    n = 0
    def wrapped(*args, **kwargs):
        nonlocal n
        n += 1
        if n % 1000 == 1:
            print('method {} called {} times'.format(f.__name__, n))
        return f(*args, **kwargs)
    return wrapped

@print_call_counts
def split_sentences(review):
    raw_sentences = tokenizer.tokenize(review.strip())
    sentences = [clean_text(s) for s in raw_sentences if s]
    return sentences

'''
sum(iterable[, start]) 就是求一个可迭代对象（iterable）的和，start 参数是可选的，start 就是求这个和之前的初值。
比如，对于一个列表（可迭代对象） li = [1, 2, 3, 4]，sum(li) 就等于 10；如果指定一个初值，比如 5，那么 sum(li, 5) 就等于 5 + sum(li)，
就是 15。列表 d = [[1, 2], [3, 4], [5, 6]]，那么 sum(d) 就是 [1, 2] + [3, 4] + [5, 6]，也就是 [1, 2, 3, 4, 5, 6]；sum(d, []) 
显然就是 [] + [1, 2] + [3, 4] + [5, 6]，结果还是 [1, 2, 3, 4, 5, 6]；如果你修改第二个参数，变为 sum(d, [9])，
那么结果就是 [9, 1, 2, 3, 4, 5, 6]
d = [[1,2,3],[4,5]]
s = sum(d, [])
print(s)#[1, 2, 3, 4, 5]
IPython专门提供了两个魔术函数（%time和%timeit）%time一次执行一条语句，然后报告总体执行时间，%%time好像是整个程序执行完毕的时间。测试一下各个部分或函数调用或语句的执行时间
# split每次返回一个raw的句子，sum可以将这些句子合并成一个二维的list
'''
%time sentences = sum(df.review.apply(split_sentences), [])
print('{} reviews -> {} sentences'.format(len(df), len(sentences)))