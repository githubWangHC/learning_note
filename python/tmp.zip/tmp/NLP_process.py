===Tokenize===
regex  http://www.regexlab.com/zh/regref.htm
===转义字符：\加普通字符成为转义字符 \t,\n；特殊字符加\成为普通字符\$,\^,\.
表达式 "\$d"，在匹配字符串 "abc$de" 时，匹配结果是：成功；匹配到的内容是："$d"；匹配到的位置是：开始于3，结束于5。
===匹配 '多种字符' 其中的任意一个字符
\d  任意一个数字，0~9 中的任意一个
\w  任意一个字母或数字或下划线，也就是 A~Z,a~z,0~9,_ 中任意一个
\s  包括空格、制表符、换页符等空白字符的其中任意一个
.   小数点可以匹配除了换行符（\n）以外的任意一个字符
表达式 "\d\d"，在匹配 "abc123" 时，匹配的结果是：成功；匹配到的内容是："12"；匹配到的位置是：开始于3，结束于5。
表达式 "a.\d"，在匹配 "aaa100" 时，匹配的结果是：成功；匹配到的内容是："aa1"；匹配到的位置是：开始于1，结束于4。
===能够匹配 '多种字符' 的表达式
[ab5@]  匹配 "a" 或 "b" 或 "5" 或 "@"
[^abc]  匹配 "a","b","c" 之外的任意一个字符
[f-k]   匹配 "f"~"k" 之间的任意一个字母
[^A-F0-3]   匹配 "A"~"F","0"~"3" 之外的任意一个字符
表达式 "[bcd][bcd]" 匹配 "abc123" 时，匹配的结果是：成功；匹配到的内容是："bc"；匹配到的位置是：开始于1，结束于3。
表达式 "[^abc]" 匹配 "abc123" 时，匹配的结果是：成功；匹配到的内容是："1"；匹配到的位置是：开始于3，结束于4。
===修饰匹配次数的特殊符号  "次数修饰"放在"被修饰的表达式"后边。比如："[bcd][bcd]" 可以写成 "[bcd]{2}"。
{n} 表达式重复n次，比如：点击测试 "\w{2}" 相当于 "\w\w"；点击测试 "a{5}" 相当于 "aaaaa"
{m,n}   表达式至少重复m次，最多重复n次，比如：点击测试 "ba{1,3}"可以匹配 "ba"或"baa"或"baaa"
{m,}    表达式至少重复m次，比如：点击测试 "\w\d{2,}"可以匹配 "a12","_456","M12344"...
?   匹配表达式0次或者1次，相当于 {0,1}，比如：点击测试 "a[cd]?"可以匹配 "a","ac","ad"
+   表达式至少出现1次，相当于 {1,}，比如：点击测试 "a+b"可以匹配 "ab","aab","aaab"...
*   表达式不出现或出现任意次，相当于 {0,}，比如：点击测试 "\^*b"可以匹配 "b","^^^b"...
表达式 "\d+\.?\d*" 在匹配 "It costs $12.5" 时，匹配的结果是：成功；匹配到的内容是："12.5"；匹配到的位置是：开始于10，结束于14。
表达式 "go{2,8}gle" 在匹配 "Ads by goooooogle" 时，匹配的结果是：成功；匹配到的内容是："goooooogle"；匹配到的位置是：开始于7，结束于17。
===代表抽象意义的特殊符号
^   与字符串开始的地方匹配，不匹配任何字符
$   与字符串结束的地方匹配，不匹配任何字符
\b  匹配一个单词边界，也就是单词和空格之间的位置，不匹配任何字符
表达式 "^aaa" 在匹配 "xxx aaa xxx" 时，匹配结果是：失败。因为 "^" 要求与字符串开始的地方匹配，因此，只有当 "aaa" 位于字符串的开头的时候，"^aaa" 才能匹配，点击测试 比如："aaa xxx xxx"。
表达式 "aaa$" 在匹配 "xxx aaa xxx" 时，匹配结果是：失败。因为 "$" 要求与字符串结束的地方匹配，因此，只有当 "aaa" 位于字符串的结尾的时候，"aaa$" 才能匹配，点击测试 比如："xxx xxx aaa"。
表达式 ".\b." 在匹配 "@@@abc" 时，匹配结果是：成功；匹配到的内容是："@a"；匹配到的位置是：开始于2，结束于4。进一步说明："\b" 与 "^" 和 "$" 类似，本身不匹配任何字符，但是它要求它在匹配结果中所处位置的左右两边，其中一边是 "\w" 范围，另一边是 非"\w" 的范围。
表达式 "\bend\b" 在匹配 "weekend,endfor,end" 时，匹配结果是：成功；匹配到的内容是："end"；匹配到的位置是：开始于15，结束于18。

regex_str = [
emoticons_str,
r'<[^>]+>', # HTML tags
r'(?:@[\w_]+)', # @某⼈
r"(?:\#+[\w_]+[\w\'_\-]*[\w_]+)", # 话题标签
r'http[s]?://(?:[a-z]|[0-9]|[$-_@.&amp;+]|[!*\(\),]|(?:%[0-9a-f][0-9a-f]))+',
# URLs
r'(?:(?:\d+,?)+(?:\.?\d+)?)', # 数字
r"(?:[a-z][a-z'\-_]+[a-z])", # 含有 - 和 ‘ 的单词
r'(?:[\w_]+)', # 其他
r'(?:\S)' # 其他
]
from bs4 import BeautifulSoup
example = BeautifulSoup(raw_example, 'html.parser').get_text()
example_letters = re.sub(r'[^a-zA-Z]', ' ', example)#去掉标点


tokens_re = re.compile(r'('+'|'.join(regex_str)+')', re.VERBOSE | re.IGNORECASE)
emoticon_re = re.compile(r'^'+emoticons_str+'$', re.VERBOSE | re.IGNORECASE)
def tokenize(s):
return tokens_re.findall(s)
def preprocess(s, lowercase=False):
tokens = tokenize(s)
if lowercase:
tokens = [token if emoticon_re.search(token) else token.lower() for token in
tokens]
return tokens
tweet = 'RT @angelababy: love you baby! :D http://ah.love #168cm'
print(preprocess(tweet))
# ['RT', '@angelababy', ':', 'love', 'you', 'baby',
# ’!', ':D', 'http://ah.love', '#168cm']

jieba 处理思路：349046个 词 词频 词性
dict_file=open("module"+os.sep+"hanlp"+os.sep+"resume_nouns.txt",'r',encoding='utf8')
d={}
[d.update({line:len(line.split(" ")[0])}) for line in dict_file]
f=sorted(d.items(), key=lambda x:x[1], reverse=True)
dict_file=open("module"+os.sep+"hanlp"+os.sep+"resume_nouns1.txt",'w',encoding='utf8')
[dict_file.write(item[0]) for item in f]
dict_file.close()

[jieba.suggest_freq(line.strip(), tune=True) for line in open("dict.txt",'r',encoding='utf8')]调整频率
pos=pd.read_excel('data/pos.xls',header=None,index=None)
cw = lambda x: list(jieba.cut(x))
pos['words'] = pos[0].apply(cw)

根据词性进行过滤停用词
drop_pos_set=set(['wky','wkz','wp','ws','wyy','wyz','wb','u','ud','ude1','ude2','ude3','udeng','udh','p','rr'])
def to_string(sentence):
    return [(word_pos_item.toString().split('/')[0],word_pos_item.toString().split('/')[1]) for word_pos_item in Tokenizer.segment(sentence)]
    #Tokenizer.segment(sentence) 切分的结果好像是 词/词性的组合。这个循环将这种组合合并成列表

def seg_sentences(sentence):  
    segs=to_string(sentence)
    g = [word_pos_pair[0] for word_pos_pair in segs if len(word_pos_pair)==2 and word_pos_pair[0]!=' ' and word_pos_pair[1] not in drop_pos_set]
    return iter(g)
    
# 输出抽取出的关键词 f
words=[keyword for keyword,w in keywords if w>0.2]

#寻找出现次数最多的词
'''
Counter类的目的是用来跟踪值出现的次数。它是一个无序的容器类型，以字典的键值对形式存储，其中元素作为key，其计数作为value
from collections import Counter
c = Counter('gallahad')
Counter({'a': 3, 'l': 2, 'g': 1, 'h': 1, 'd': 1})
c = Counter('abracadabra')
cp = c.most_common()
[('a', 5), ('r', 2), ('b', 2), ('c', 1), ('d', 1)]
list(zip(*cp))
[('a', 'b', 'r', 'c', 'd'), (5, 2, 2, 1, 1)]
'''
counter = Counter(all_data)
count_pairs = counter.most_common(vocab_size - 1)
words, _ = list(zip(*count_pairs))

#生成可迭代对象
from itertools import chain
string = chain.from_iterable('ABCD')
list(string)  #['A', 'B', 'C', 'D']
#实例
list(chain.from_iterable([_w2f(word) for word in jieba.cut(string) if len(word.strip())>0]))

# PAD 填充
# 使用keras提供的pad_sequences来将文本pad为固定长度
# 为序列的最大长度。大于此长度的序列将被截短，小于此长度的序列将在后
# pre ’或‘post’，确定当需要截断序列时，从起始还是结尾截断
x_pad = kr.preprocessing.sequence.pad_sequences(data_id, max_length, truncating='pre')

def get_words(sentence):     

    segs = (word_pos_item.toString().split('/') for word_pos_item in StandardTokenizer.segment(sentence))
    segs = (tuple(word_pos_pair) for word_pos_pair in segs if len(word_pos_pair)==2)
    segs = ((word.strip(),pos) for word, pos in segs if pos  in keep_pos_set)
    segs = ((word, pos) for word, pos in segs if word and not pattern.search(word))
    result = ' '.join(w for w,pos in segs if len(w)>0)    
    return result
 
def tokenize_raw(text):
    split_sen=(i.strip() for i in re.split('。|,|，|：|:|？|！|\t|\n',_replace_c(text)) if len(i.strip())>5)
    return [get_words(sentence) for sentence in split_sen]

# 停止词
from nltk.corpus import stopwords
stop = stopwords.words('english')

# 数字
import re
def hasNumbers(inputString):
    return bool(re.search(r'\d', inputString))

# 特殊符号
def isSymbol(inputString):
    return bool(re.match(r'[^\w]', inputString))

===Lemma/Stemming===

from nltk.stem.porter import PorterStemmer
porter_stemmer = PorterStemmer()
porter_stemmer.stem(‘multiply’) #u’multipli’

from nltk.stem import SnowballStemmer
snowball_stemmer = SnowballStemmer(“english”)
snowball_stemmer.stem(‘presumably’) #u’presum’

from nltk.stem.lancaster import LancasterStemmer
lancaster_stemmer = LancasterStemmer()
lancaster_stemmer.stem(‘presumably’)    #‘presum’

from nltk.stem import WordNetLemmatizer
wordnet_lemmatizer = WordNetLemmatizer()
wordnet_lemmatizer.lemmatize(‘dogs’) #u’dog’

===POS Tag===
import nltk
text = nltk.word_tokenize('what does the fox say')
text
['what', 'does', 'the', 'fox', 'say']
nltk.pos_tag(text)
[('what', 'WDT'), ('does', 'VBZ'), ('the', 'DT'), ('fox', 'NNS'), ('say', 'VBP')]

 stopwords Word_List
jieba.cut(sentence, cut_all = False)
jieba.cut_for_search(sentence, HMM = True)
将一个str格式的sentence切分为list
英文分词
texts = [[w for w in line.lower().split()] for line in corpus]

seg_list = genius.seg_text(u"我爱文本数据分析",use_tagging=True)

NLTK 处理英文，可以英文分词，去除停用词，词性标注，找出固定搭配

drop stop word
def load_stopword():
    f_stop = open('22.stopword.txt')
    sw = [line.strip() for line in f_stop]# str.strip('-'),将str前后的 - 都删掉
    f_stop.close()
    return sw

stop_words = load_stopword()
f = open('news.txt', encoding = 'utf-8')    
texts = [[word for word in line.strip().lower().split() if word not in stop_words] for line in f]

#keys2 = ['a', 'e', 'i', 'o', 'u' ]
#vowels = {}.fromkeys(keys2)
#{'a': None, 'e': None, 'i': None, 'o': None, 'u': None}

stopwords = {}.fromkeys([ line.rstrip() for line in open('../stopwords.txt')])
words_nostop = [w for w in words if w not in stopwords]

corpus:list_list形式[[w1,w2,w3,w4], [w5,w6,w7],......]
stopwords_list:list形式['"', '#', '!',...]
print("   ".join(jieba.analyse.extract_tags(contents, topK = 5, withWeight = False))) #with 是小写

gensim 生成文本向量
c_dict = corpora.Dictionary(list_str)
c_vec = [c_dict.doc2bow(s) for s in list_str]
一种可能的等价
for line in corpus:
    bow.append([(w, True) for w in line])
doc2bow 将每一句中的词用之前转换好的一个数字代替；['呼叫', '热线', ...] => [(196, 1), (197, 1),...]
lda = models.ldamodel.LdaModel(corpus = c_vec, id2word = c_dict, num_topics = 5)

term_distribute_all=lda.get_topic_terms(topicid=0, topn = 10)#第0个主题的前10个主题词，排序，词向量加概率,list的形式
[(208, 0.014023398), (7, 0.012743309),...]
term_distribute=np.array(term_distribute_all[:num_show_term])
term_id = term_distribute[:, 0].astype(np.int)
for t in term_id:
   print(dictionary.id2token[t],)
print('\n概率：\t', term_distribute[:, 1])

doc_topics=lda.get_document_topics(c_vec)
所有文章分别属于5个主题的可能性（所有文档的主题分布）是[(3, 0.9974439)]
topic = np.array(doc_topics[i])第i个文档所对应的主题及概率[(3, 0.9974439)]
topic_distribute = np.array(topic[:, 1])第i个文档属于1到5个主题的概率，只有概率。
topic_idx = topic_distribute.argsort()[:-num_show_topic-1:-1]，排序后输出索引
print("前5个主题是",topic_idx,"对应的分布是",topic_distribute[topic_idx])

文档--词项矩阵
from sklearn.feature_extraction.text import CountVectorizer
cv = CountVectorizer(stop_words = list, lowercase=False) 
x = cv.fit_transform(corpus)
corpus是list+str(未分词),不能是list+list,最好先用jieba分词完之后的list用空格连起来作为str
line_space = ' '.join(line)
corpus_split_space.append(line_space)

TF-IDF
文档总词汇数是 100，“经济”这个词汇出现了 4次，则“经济”TF为 4/100 = 0.04，如果在 1000 个文档中有 100 个文档出现过“经济”一词，则逆向文档频率（IDF） 为 log(1000/100) = 1，那么在 TF-IDF 矩阵中，该文档中“经济”一词对应的权数应为 0.04 * 1 = 0.04

==== TFIDF ======
term frequency-inverse document frequency 逆文档频率分析
from sklearn.feature_extraction.text import TfidfVectorizer
tf = TfidfVectorizer()
data = tf.fit_transform([c1, c2, c3])
print(tf.get_feature_names())
print(data.toarray())
input c1 应该是string，中间用空格分隔，分词后用空格将list连接起来。
data[0]中应该是一个包含每一个词的稀疏矩阵，以及对应的tfidf值
TF= Na/N,a词在一篇文档中出现的概率
IDF= ln(D/(Da + 1)),包含a词的文档所占的比例。

=== word2vec
list_list = [[w.lower() for w in line] for line in corpus]
w2v_model = gensim.models.Word2Vec(list_list, size = 100, window = 5, min_count = 3)
# If you don't plan to train the model any further, calling 
# init_sims will make the model much more memory-efficient.
#If replace is set, forget the original vectors and only keep the normalized ones = saves lots of memory! Note that you cannot continue training after doing a replace. The model becomes effectively read-only = you can call most_similar, similarity etc., but not train.
w2v_model.init_sims(replace=True)
#w2v_model得到的类似一个字典，可以用 w2v_model[w] 来索引
array = np.array([w2v_model[w] for w in words if w in w2v_model])
pd.Series(array.mean(axis=0))
model_name = '{}features_{}minwords_{}context.model'.format(num_features, min_word_count, context)
w2v_model.save(os.path.join('..', 'models', model_name))
w2v_model.wv.save(os.path.join('..', 'models', model_name))

word_centroid_map = dict(zip(model.index2word, idx))
wordset = set(word_centroid_map.keys())

def make_cluster_bag(review):
    words = clean_text(review, remove_stopwords=True)
    return (pd.Series([word_centroid_map[w] for w in words if w in wordset])
              .value_counts()
              .reindex(range(num_clusters+1), fill_value=0))

# Save a dictionary into a pickle file
import pickle
with open(os.path.join('..', 'models', model_name), 'bw') as f:
    pickle.dump(word_centroid_map, f)
    
with open(os.path.join('..', 'models', filename), 'br') as f:
    word_centroid_map = pickle.load(f)  

dont_match = w2v_model.doesnt_match(['breakfast', 'cereal', 'dinner', 'lunch'])
most_similar = w2v_model.most_similar(positive=["woman","king"],negative=["man"],topn=5)
与woman king 最接近，与 man 最远离
similarity = w2v_model.n_similarity(['old', 'lady'], ['young', 'boy'])两组词的相似度
w2v_model.similar_by_word('nice',topn=5)与nice最相近的5个词语
w2v_model.similarity('pleasure', 'dog')两词的相似度

from sklearn import metrics

labels_true = [0, 0, 1, 1, 1]
labels_pred = [0, 0, 1, 1, 2]

metrics.adjusted_rand_score(labels_true, labels_pred)调整兰德指数

metrics.normalized_mutual_info_score(labels_true, labels_pred)互信息
I(X;Y)=H(X)-H(X|Y)=H(X,Y)-H(X|Y)-H(Y|X)

metrics.homogeneity_score(labels_true, labels_pred)同质性
metrics.completeness_score(labels_true, labels_pred)完备性

print(X.shape, y.shape)  (5, 4) (5,)轮廓系数
metrics.silhouette_score(X, y, metric='euclidean')

from wordcloud import WordCloud
word_frequence = {x[0]:x[1] for x in words_count.head(100).values}
wordcloud=wordcloud.fit_words(word_frequence)
plt.imshow(wordcloud)


===Keras框架下的 LSTM

from keras.utils import np_utils

seq_length = 100
n_patterns = len(x)
n_vocab = len(chars)

# 把x变成LSTM需要的样子 LSTM需要的数组格式： [样本数，时间步伐，特征]，每一个特征都是一维向量
x = numpy.reshape(x, (n_patterns, seq_length, 1))
# 简单normal到0-1之间
x = x / float(n_vocab)
# output变成one-hot，这样的话训练速度会快很多
y = np_utils.to_categorical(y)

model = Sequential()#一层层的模型
model.add(LSTM(128, dropout_W=0.2, dropout_U=0.2, input_shape=(x.shape[1], x.shape[2])))
model.add(Dropout(0.2))#避免过拟合
model.add(Dense(y.shape[1], activation='softmax'))#
model.compile(loss='categorical_crossentropy', optimizer='adam')#优化器的类型

model.fit(x, y, nb_epoch=10, batch_size=32)

def predict_next(input_array):
    x = numpy.reshape(input_array, (1, seq_length, 1))
    x = x / float(n_vocab)
    y = model.predict(x)
    return y

def string_to_index(raw_input):
    res = []
    for c in raw_input[(len(raw_input)-seq_length):]:
        res.append(char_to_int[c])
    return res

def y_to_char(y):
    largest_index = y.argmax()
    c = int_to_char[largest_index]
    return c

def generate_article(init, rounds=500):
    in_string = init.lower()
    for i in range(rounds):
        n = y_to_char(predict_next(string_to_index(in_string)))
        in_string += n
    return in_string
    
init = 'Professor Michael S. Hart is the originator of the Project'
article = generate_article(init)
print(article)

===============

raw_text = ''
for file in os.listdir("../input/"):
    if file.endswith(".txt"):
        raw_text += open("../input/"+file, errors='ignore').read() + '\n\n'
# raw_text = open('../input/Winston_Churchil.txt').read()
raw_text = raw_text.lower()
sentensor = nltk.data.load('tokenizers/punkt/english.pickle')        
sents = sentensor.tokenize(raw_text)#句子分割
corpus = []
for sen in sents:
    corpus.append(nltk.word_tokenize(sen))

print(len(corpus))
print(corpus[:3])

raw_input = [item for sublist in corpus for item in sublist]#corups[sentence[word]]

=====CNN4Text
CNN考虑的是能否为所有可能的短语组合生成向量，不在乎是否符合语法，自然也就不需要parser。比如“The country of my birth”，计算所有可能出现的短语的向量：the country、country of、of my、my birth、the country of、country of my、of my birth、the country of my、 country of my birth。

=====
按照固定长度进行填充是一种算力浪费，可以使用 bucket 模型
# 每个样本取前256个单词的向量 append  堆在一起形成一个长列， 相当于单词一个个排列起来， 上下两行相当于原来句子中的前后关系， 只不过原来样本中x[0]与x[1]之间没有更明显的区分。
# 说明，对于每天的新闻，我们会考虑前256个单词。不够的我们用[000000]补上
# vec_size 指的是我们本身vector的size
def transform_to_matrix(x, padding_size=256, vec_size=128):
    res = []
    for sen in x:
        matrix = []#初始为空
        for i in range(padding_size):
            try:
                matrix.append(model[sen[i]].tolist())#[[1, 2, 3], [4, 5]]
            except:
                # 这里有两种except情况，
                # 1. 这个单词找不到
                # 2. sen没那么长
                # 不管哪种情况，我们直接贴上全是0的vec
                matrix.append([0] * vec_size)
        res.append(matrix)
    return res

X_train = [preprocessing(x) for x in X_train]#这时还是句子。
wordlist_train = X_train
X_train = transform_to_matrix(wordlist_train)#(1611, 256, 128)，一共有 1611 个单词
X_test = transform_to_matrix(wordlist_test)#(378, 256, 128)

X_test = np.array(X_test)
#告诉CNN，前后两个单词是没有关系的？相当于在LSTM中将步长设置为100
X_train = X_train.reshape(X_train.shape[0], 1, X_train.shape[1], X_train.shape[2]) #(1611, 1, 256, 128)
X_test = X_test.reshape(X_test.shape[0], 1, X_test.shape[1], X_test.shape[2])#(378, 1, 256, 128)

from keras.preprocessing import sequence
from keras.models import Sequential
from keras.layers import Convolution2D, MaxPooling2D
from keras.layers.core import Dense, Dropout, Activation, Flatten

# set parameters:
batch_size = 32
n_filter = 16
filter_length = 4
nb_epoch = 5
n_pool = 2

# 新建一个sequential的模型
model = Sequential()
model.add(Convolution2D(n_filter,filter_length,filter_length,
                        input_shape=(1, 256, 128)))
model.add(Activation('relu'))
model.add(Convolution2D(n_filter,filter_length,filter_length))
model.add(Activation('relu'))
model.add(MaxPooling2D(pool_size=(n_pool, n_pool)))
model.add(Dropout(0.25))
model.add(Flatten())#将学习到的特征值平坦化
# 后面接上一个ANN
model.add(Dense(128))
model.add(Activation('relu'))
model.add(Dropout(0.5))
model.add(Dense(1))
model.add(Activation('softmax'))
# compile模型
model.compile(loss='mse',
              optimizer='adadelta',
              metrics=['accuracy'])
              
===FastText
https://github.com/facebookresearch/fastText/tree/master/python
#fastText是一种Facebook AI Research在16年开源的一个文本分类器。 其特点就是fast。相对于其它文本分类模型，如SVM，Logistic Regression和neural network等模型，fastText在保持分类效果的同时，大大缩短了训练时间。
#fastText 模型输入一个词的序列（一段文本或者一句话)，输出这个词序列属于不同类别的概率。 
序列中的词和词组组成特征向量，特征向量通过线性变换映射到中间层，中间层再映射到标签。 
fastText 在预测标签时使用了非线性激活函数，但在中间层不使用非线性激活函数。 
fastText 模型架构和 Word2Vec 中的 CBOW 模型很类似。不同之处在于，fastText 预测标签，而 CBOW 模型预测中间词。 
第一部分：fastText的模型架构类似于CBOW，两种模型都是基于Hierarchical Softmax，都是三层架构：输入层、 隐藏层、输出层。 
CBOW模型又基于N-gram模型和BOW模型，此模型将W(t−N+1)……W(t−1)W(t−N+1)……W(t−1)作为输入，去预测W(t) 
fastText的模型则是将整个文本作为特征去预测文本的类别。

第二部分：层次之间的映射 
将输入层中的词和词组构成特征向量，再将特征向量通过线性变换映射到隐藏层，隐藏层通过求解最大似然函数，然后根据每个类别的权重和模型参数构建Huffman树，将Huffman树作为输出。
第三部分：fastText的N-gram特征 
常用的特征是词袋模型（将输入数据转化为对应的Bow形式）。但词袋模型不能考虑词之间的顺序，因此 fastText 还加入了 N-gram 特征

for i in range(len(y_train)):
    label = '__label__' + str(y_train[i])# __label__ 是facebook开源fastTest中固定的表示标签的标志
    X_train[i].append(label)

X_train = [' '.join(x) for x in X_train]

X_test = [' '.join(x) for x in X_test]
#文本存下来之后其他程序要用
with open('../input/train_ft.txt', 'w') as f:
    for sen in X_train:
        f.write(sen+'\n')

with open('../input/test_ft.txt', 'w') as f:
    for sen in X_test:
        f.write(sen+'\n')

with open('../input/test_label_ft.txt', 'w') as f:
    for label in y_test:
        f.write(str(label)+'\n')
import fasttext

clf = fasttext.supervised('../input/train_ft.txt', 'model', dim=256, ws=5, neg=5, epoch=100, min_count=10, lr=0.1, lr_update_rate=1000, bucket=200000)

y_scores = []

# 我们用predict来给出判断
labels = clf.predict(X_test)

y_preds = np.array(labels).flatten().astype(int)

# 我们来看看
print(len(y_test))
print(y_test)
print(len(y_preds))
print(y_preds)

from sklearn import metrics

# 算个AUC准确率
fpr, tpr, thresholds = metrics.roc_curve(y_test, y_preds, pos_label=1)
print(metrics.auc(fpr, tpr))
========seq2seq
Seq2seq全名是Sequence-to-sequence，也就是从序列到序列的过程，是近年当红的模型之一。Seq2seq被广泛应用在机器翻译、聊天机器人甚至是图像生成文字等情境。
典型的Seq2seq模型，包含了编码器（Encoder）和解码器（Decoder）.只要输入句子至Encoder，即可从Decoder获得目标句。举例来说，如果我们将“Are you very big”作为输入句（source sentence），即可得到目标句（target sentence）“你很大？”。
Encoder就是个单纯的RNN/ LSTM，读者若有兴趣可再自行研究，此外RNN/LSTM可以互相代替，以下仅以RNN作为解释。
Seq2seq中，Decoder的公式和RNN根本就是同一个模子出来的，差别在于Decoder多了一个C — 图（6），这个C是指context vector/thought vector。context vector可以想成是一个含有所有输入句信息的向量，也就是Encoder当中，最后一个hidden state。简单来说，Encoder将输入句压缩成固定长度的context vector，context vector即可完整表达输入句，再透过Decoder将context vector内的信息产生输出句，

==============attention
很明显，引入Self Attention后会更容易捕获句子中长距离的相互依赖的特征，因为如果是RNN或者LSTM，需要依次序序列计算，对于远距离的相互依赖的特征，要经过若干时间步步骤的信息累积才能将两者联系起来，而距离越远，有效捕获的可能性越小。
但是Self-Attention在计算过程中会直接将句子中任意两个单词的联系通过一个计算步骤直接联系起来，所以远距离依赖特征之间的距离被极大缩短，有利于有效地利用这些特征。除此外，Self-Attention对于增加计算的并行性也有直接帮助作用。这是为何Self Attention逐渐被广泛使用的主要原因。

Attention Mechanism可以帮助模型对输入的X每个部分赋予不同的权重，抽取出更加关键及重要的信息，使模型做出更加准确的判断，同时不会对模型的计算和存储带来更大的开销，这也是Attention Mechanism应用如此广泛的原因
1、把输入X的所有信息有压缩到一个固定长度的隐向量Z，忽略了输入输入X的长度，当输入句子长度很长，特别是比训练集中最初的句子长度还长时，模型的性能急剧下降。

2、把输入X编码成一个固定的长度，对于句子中每个词都赋予相同的权重，这样做是不合理的，比如，在机器翻译里，输入的句子与输出句子之间，往往是输入一个或几个词对应于输出的一个或几个词。因此，对输入的每个词赋予相同权重，这样做没有区分度，往往是模型性能下降。

h1, h2, h3 = Encoder(x1, x2, x3)
Encoder函数可以对输入英文单词x1, x2, x3施加某种变换，比如如果Encoder是用的RNN模型的话，这个函数的结果往往是某个时刻输入xi后隐层节点的状态值；

e11 = a(0, h1)
e12 = a(0, h2)
e13 = a(0, h3)

对于采用RNN的Decoder来说，si-1指的是在发射出Yi之前的i-1时刻隐藏节点的输出值。输入x1,x2,x3...对i时刻发射出Target Yi的注意力分配概率分布用Target输出句子i-1时刻的隐层节点状态si-1去和输入句子Source中每个单词对应的RNN隐层节点状态hj进行对比，即通过函数a(hj,Hi-1)来获得目标单词yi和每个输入单词对应的对齐可能性，这个a函数在不同论文里可能会采取不同的方法，然后函数a的输出经过Softmax进行归一化就得到了符合概率分布取值区间的注意力分配概率分布数值。
e21 = a(s1, h1)
e22 = a(s1, h2)
e23 = a(s1, h3)

a11 = exp(e11) / (exp(e11) + exp(e12) + exp(e13))
a12 = exp(e12) / (exp(e11) + exp(e12) + exp(e13))
a13 = exp(e13) / (exp(e11) + exp(e12) + exp(e13))

a21 = exp(e21) / (exp(e21) + exp(e22) + exp(e23))
a22 = exp(e22) / (exp(e21) + exp(e22) + exp(e23))
a23 = exp(e23) / (exp(e21) + exp(e22) + exp(e23))

ci = g(ai1*h1, ai2*h2, ...)
c1 = a11 * h1 + a12 * h2 + a13 * h3
c2 = a21 * h1 + a22 * h2 + a23 * h3
g代表Encoder根据单词的中间表示合成整个句子中间语义表示的变换函数，一般的做法中，g函数就是对构成元素加权求和
aij代表在Target输出第i个单词时Source输入句子中第j个单词的注意力分配系数，而hj则是Source输入句子中第j个单词的语义编码。

s1 = Decoder(c1)

https://machinelearningmastery.com/how-does-attention-work-in-encoder-decoder-recurrent-neural-networks/

将Source中的构成元素想象成是由一系列的<Key,Value>数据对构成，此时给定Target中的某个元素Query，通过计算Query和各个Key的相似性或者相关性，得到每个Key对应Value的权重系数，然后对Value进行加权求和，即得到了最终的Attention数值。所以本质上Attention机制是对Source中元素的Value值进行加权求和，而Query和Key用来计算对应Value的权重系数。

在一般任务的Encoder-Decoder框架中，输入Source和输出Target内容是不一样的，比如对于英-中机器翻译来说，Source是英文句子，Target是对应的翻译出的中文句子，Attention机制发生在Target的元素Query和Source中的所有元素之间。而Self-Attention顾名思义，指的不是Target和Source之间的Attention机制，而是Source内部元素之间或者Target内部元素之间发生的Attention机制，也可以理解为Target=Source这种特殊情况下的注意力计算机制。
https://zhuanlan.zhihu.com/p/37601161

https://jalammar.github.io/illustrated-transformer/

http://nlp.seas.harvard.edu/2018/04/03/attention.html

绝大部分NLP问题可以归入上图所示的四类任务中：一类是序列标注，这是最典型的NLP任务，比如中文分词，词性标注，命名实体识别，语义角色标注等都可以归入这一类问题，它的特点是句子中每个单词要求模型根据上下文都要给出一个分类类别。第二类是分类任务，比如我们常见的文本分类，情感计算等都可以归入这一类。它的特点是不管文章有多长，总体给出一个分类类别即可。第三类任务是句子关系判断，比如Entailment，QA，语义改写，自然语言推理等任务都是这个模式，它的特点是给定两个句子，模型判断出两个句子是否具备某种语义关系；第四类是生成式任务，比如机器翻译，文本摘要，写诗造句，看图说话等都属于这一类。它的特点是输入文本内容后，需要自主生成另外一段文字。

===BERT
第一级decoder的key, query, value均来自前一层decoder的输出，但加入了Mask操作，即我们只能attend到前面已经翻译过的输出的词语，因为翻译过程我们当前还并不知道下一个输出词语，这是我们之后才会推测到的。

而第二级decoder也被称作encoder-decoder attention layer，即它的query来自于之前一级的decoder层的输出，但其key和value来自于encoder的输出，这使得decoder的每一个位置都可以attend到输入序列的每一个位置。

总结一下，k和v的来源总是相同的，q在encoder及第一级decoder中与k,v来源相同，在encoder-decoder attention layer中与k,v来源不同。

===word2vec 推荐系统
https://towardsdatascience.com/using-word2vec-for-music-recommendations-bb9649ac2484
基于用户浏览记录的推荐系统
https://new.qq.com/omn/20180107/20180107A08O7T.html
https://blog.csdn.net/Tong_T/article/details/80366407
取出用户的
we can think of a user’s listening queue as a sentence, with each word in that sentence being a song that the user has listened to. So then, training the Word2vec model on those sentences essentially means that for each song the user has listened to in the past, we’re using the songs they have listened to before and after to teach our model that those songs somehow belong to the same context. Here’s an idea of what the neural network would look like with songs instead of words:

As we have previously mentioned, the more times two particular songs appear in similar contexts, the closer their coordinates will be. So given a particular seed song, we can find k other similar songs by taking the cosine similarity between the vector of this seed song and all the others while keeping the top k ones that have the highest cosines (which correspond to the lowest angles, and therefore the most similar).

Another interesting way in which we can use the song vectors is to map a user’s listening habits onto this space and generate recommendations based on that. Since we’re now dealing with vectors, we can use basic arithmetic to add vectors together. Let’s take for example a user who has listened to three songs: Keaton Henson’s In the Morning, London Grammar’s Wasting My Young Years and Daughter’s Youth. What we can do is get the vectors corresponding to each of those three songs, and average them out together to find a point that is equidistant from all three songs. What we have essentially done is transform a list of songs that the user has listened to into a vector of coordinates that represents the user in the same vector space in which our songs are located. Now that we have a vector that defines the user, we can use the same technique used previously to find similar songs with points that are close to the user. The following animation helps visualize the different steps involved in generating those recommendations: