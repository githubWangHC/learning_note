易错点

数据的获得
img_batch, label_batch = tf.train.batch([f1, l1], num_threads = 2, batch_size = 10, capacity = 2)
批处理前f1、f2的形状要固定，否则不知一次要读取多少字节。一次读10行(csv)或者10倍固定长度。
return img_batch, label_batch

模型的建立
x = tf.placeholder(tf.float32, [None, h, w, c])
y_true = tf.placeholder(tf.float32, [None, N_classifier])
类型加形状，形状要和后续feed进来的tensor形状一致，检查形状用 x.shape
x_reshape = tf.reshape(x, shape = [-1, h * w * c])
矩阵为二维，单个数值：[[10.0]]

每个样本有 h * w * c 个特征，要被分到 N_classifier 个类别，对于任意一个样本用w都可以得到N个类别的概率；每一个类别都对应一个bias
w = tf.Variable(tf.random_normal([h * w * c, N_classifier], mean = 0, stddev = 1, name = 'w'))
weight = tf.Variable(w)  直接是数值，正态分布中第一个参数是列表，constant有shape这个参数
bias = tf.Variable(tf.constant(0.0, shape = [N_classifier]))
------------------------
init_op = tf.global_variables_initializer()
y_predict = tf.matmul(x_reshape, weight) + bias
===========================================
卷积神经网络和普通网络参数初始化相似，只是部分做调整
x_reshpe.getshape = [batch1,H1,W1,C1]; filter数量K，filter大小F，步长S，零填充大小P, w_conv1.getshape = [F,F,C1,K*C1]; b_conv1.getshape = [k*C1]
x_relu1.getshape = [batch1,H2,W2,C2];H2 = W2 = (H1 -F + 2P)/S + 1;C2 = K * C1

x_relu1 = tf.nn.relu(tf.nn.conv2d(x_reshpe, w_conv1, strides = [1, 1, 1, 1], padding = "SAME")) + b_conv1
x_poo1_1 = tf.nn.max_pool(x_relu1, ksize = [1, 2, 2, 1], strides = [1, 2, 2, 1], padding = "SAME")

fc_input = tf.reshape(x_poo1_n, shape = [-1, 4 * 4 * 8 * 3 * 16])
y_predict = tf.matmul(fc_input, w_fc) + b_fc
============================================
equal_list = tf.equal(tf.argmax(y_predict, 1), tf.argmax(y_true, 1))
acc = tf.reduce_mean(tf.cast(equal_list, tf.float32))  整数不能用于计算平均

均方误差
error = tf.square(y_predict - y_train)  每一行计算
loss = tf.reduce_mean(error)       求均值
交叉熵损失
loss = tf.nn.softmax_cross_entropy_with_logits(labels = y_true, logits = y_predict)
在nn下面，labels为真实标签

train_op = tf.train.GradientDescentOptimizer(0.1).minimize(loss)
在tain 下面, minimize
img_batch, label_batch = getdata()

with tf.Session() as sess:
cd = tf.train.Coordinator()
th = tf.train.start_queue_runners(sess, coord = cd) 
sess.run(init_op)
img, label = sess.run(img_batch, label_batch)
run的时候才能获得训练数据，或者通过.eval()

for i in range(N):
sess.run(train_op, feed_dict = {x: img, y_true: label})
sess.run(train_op, feed_dict = {x: img_batch.eval(), y_true: label_batch.eval()})
print("i = %d, acc = %f" % (i, sess.run(acc, feed_dict = {x: img, y_true: label}))
没有""将key括起来。feed_dict 是一个字典，key 的位置填 tf.placeholder 类型，val的位置填一个和key形状相同，类型相同的object

cd.request_stop()
cd.join(th)如果没有子线程回收机制会造成命令行窗口一直运行。

with tf.variable_scope(<scope_name>):

def batch_iter(x, y, batch_size=64):
    """生成批次数据"""
    data_len = len(x)
    num_batch = int((data_len - 1) / batch_size) + 1
    #生成一个打乱的索引
    indices = np.random.permutation(np.arange(data_len))
    x_shuffle = x[indices]
    y_shuffle = y[indices]

    for i in range(num_batch):
        start_id = i * batch_size
        end_id = min((i + 1) * batch_size, data_len)
        #yield https://blog.csdn.net/mieleizhi0522/article/details/82142856
        yield x_shuffle[start_id:end_id], y_shuffle[start_id:end_id]
