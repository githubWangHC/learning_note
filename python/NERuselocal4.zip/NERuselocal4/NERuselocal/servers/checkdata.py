lines=open('D:\\code\\python\\cner\\bk\\NER_IDCNN_CRF\\NER_IDCNN_CRF\\data\\example.dev','r',encoding='utf8').readlines()
for line in lines:
    print(line)
